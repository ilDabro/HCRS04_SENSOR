/*
  HCSR04_SENSOR - Library for arduino, for HC-SR04 ultrasonic distance sensor.
  Created by Antonio D'Abrosca, December, 17 2021.
*/

#include "Arduino.h"
#include "HCSR04_SENSOR.h"


UltrasonicSensor::UltrasonicSensor(byte TriggerPin, byte EchoPin){
  
  this -> TriggerPin  = TriggerPin ;
  this -> EchoPin     = EchoPin    ;
  pinMode( TriggerPin, OUTPUT);
  pinMode( EchoPin   , INPUT );
}


float UltrasonicSensor::MeasureDistance(){
  
  unsigned int SoundSpeed = 343;      //The speed of sound is approximately equal to 343 m/s
  
  digitalWrite (TriggerPin, LOW);        // Set trigger low
    digitalWrite (TriggerPin, HIGH);       // Set trigger high
    delayMicroseconds(10);          // Hold trigger for 10 microseconds so it measure the time
    digitalWrite (TriggerPin, LOW);        // Set trigger low
    
    float Time= pulseIn(EchoPin, HIGH, 20000);  
    float Distance=SoundSpeed*Time/20000;
    return Distance;
    
}
