/*
  HCSR04_SENSOR - Library for arduino, for HC-SR04 ultrasonic distance sensor.
  Created by Antonio D'Abrosca, December, 17 2021.
*/

#ifndef HCSR04_SENSOR
#define HCSR04_SENSOR

#include "Arduino.h"

class UltrasonicSensor {
  
  
  public:
    
    UltrasonicSensor (byte TriggerPin, byte EchoPin );
    
    
    /**
     * TriggerPin   -> Arduino pin linked to HCSR04 trigger pin.
     * EchoPin      -> Arduino pin linked to HCSR04 echo pin.
     * MaxDistance  -> HCSR04 max range
    **/
    
    
    float MeasureDistance();
    
    /**
     * It measure distance by sending ultrasonic waves and measuring time it takes them to return
     * Distance is returned in Cm
    **/
  
  
  private:
    
    byte TriggerPin, EchoPin;
    
    
};

#endif
